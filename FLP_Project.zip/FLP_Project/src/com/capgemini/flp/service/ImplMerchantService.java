package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.flp.dao.MerchantDAO;
import com.capgemini.flp.dao.MerchantProductDAO;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.dto.Merchants;
import com.capgemini.flp.exception.MerchantException;

public class ImplMerchantService implements IMerchantService {
	
	@Autowired
	private MerchantDAO repo;
	@Autowired
	private MerchantProductDAO repop;

	@Override
	public String addMerchant(String emailId) throws MerchantException {
		String msg=null;
		MerchantProduct merchantproduct = null;
		Merchants merchant = repo.findMerchant(emailId);
		if(merchant!=null) {
		merchantproduct=repop.findMerchantProduct(emailId);
		}
		if(merchantproduct!=null) {
		msg="Merchant Added Successfully of UserName: "+emailId;
		}
		return msg;
	}

	@Override
	public String removeMerchant(String emailId) throws MerchantException {
		String msg = null;
		 Merchants merchant = repo.findMerchant(emailId);
		 repo.delete(merchant);
		 Merchants deleted = repo.findMerchant(emailId);
		 if(deleted==null) {
		 msg="Merchant Removed Successfully of UserName: "+emailId;
		 }
		return msg;
	}

	@Override
	public String inviteMerchant(String emailId) throws MerchantException {
		String msg = null;
		Merchants merchant = repo.findMerchant(emailId);
		if(merchant!=null) {
		msg="Invitation is sent to the Merchant UserName: "+emailId;
		}
		return msg;
	}

	@Override
	public List<Merchants> findAllMerchants() throws MerchantException {
		return repo.findAll();
	}
}
