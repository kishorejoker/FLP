package com.capgemini.flp.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "merchant_login")
public class Merchants {
	
	@Id
	@NotEmpty
	private String emailId;
	@NotEmpty
	private String password;
	@NotEmpty
	private String name;
	@Pattern(regexp = "[7-9][0-9]{9}")
	@NotEmpty
	private Integer phoneNumber;
	@NotEmpty
	private String address;
	@NotEmpty
	private String organizationName;
	
	@OneToMany(cascade = CascadeType.ALL)
	private MerchantProduct product;

	public Merchants() {
		super();
	}

	public Merchants(String emailId, String password, String name, Integer phoneNumber, String address,
			String organizationName, MerchantProduct product) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.organizationName = organizationName;
		this.product = product;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public MerchantProduct getProduct() {
		return product;
	}

	public void setProduct(MerchantProduct product) {
		this.product = product;
	}

	@Override
	public String toString() {
		
		return "Merchants [emailId=" + emailId + ", password=" + password + ", name=" + name + ", phoneNumber="
				+ phoneNumber + ", address=" + address + ", organizationName=" + organizationName + ", product="
				+ product + "]";
	}

}
