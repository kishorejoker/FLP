package com.capgemini.flp.dao;

import org.springframework.data.jpa.repository.JpaRepository; 
import org.springframework.data.jpa.repository.Query;

import com.capgemini.flp.dto.Merchants;

public interface MerchantDAO extends JpaRepository<Merchants, Integer>{
	
	@Query("select m from Merchants m where m.emailId=?1 ")
	Merchants findMerchant(String emailId);
	
	
	@Query("delete from Merchants m where m.emailId = ?1")
	void deleteMerchant(String emailId);
}
