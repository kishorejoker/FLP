package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.flp.dto.Merchants;
import com.capgemini.flp.exception.MerchantException;
import com.capgemini.flp.service.IMerchantService;

@RestController
public class MerchantController {

	@Autowired
	private IMerchantService service;
	
	@RequestMapping(value="/findall")
	public List<Merchants> findall() throws MerchantException{
		return service.findAllMerchants();
	}
	
	@RequestMapping(value="/addmerchant")
	public String addMerchant(@RequestBody String emailId) throws MerchantException {
		return service.addMerchant(emailId);
	}
	
	@RequestMapping(value="/removemerchant")
	public String removeMerchant(@RequestBody String emailId) throws MerchantException {
		return service.removeMerchant(emailId);
	}
	
	@RequestMapping(value="/invitemerchant")
	public String inviteMerchant(@RequestBody String emailId) throws MerchantException {
		return service.inviteMerchant(emailId);
	}
}
